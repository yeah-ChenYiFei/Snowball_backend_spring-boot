package com.example.snowball.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity // 必须加，确保这个配置被 Spring Security 识别
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // 1）所有请求都放行（不要求登录）
                .authorizeHttpRequests(auth -> auth
                        .anyRequest().permitAll()
                )
                // 2）关闭默认的弹窗登录
                .formLogin(form -> form.disable())
                // 3）关闭 HTTP Basic
                .httpBasic(basic -> basic.disable())
                // 4）关闭 CSRF（否则 POST/PUT/DELETE 会 403）
                .csrf(csrf -> csrf.disable());

        return http.build();
    }
}
