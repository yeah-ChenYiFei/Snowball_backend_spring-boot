package com.example.snowball.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:5173")  // Vite 前端地址
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // 必须有 OPTIONS
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}
