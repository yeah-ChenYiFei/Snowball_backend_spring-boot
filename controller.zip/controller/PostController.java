package com.example.snowball.controller;

import com.example.snowball.common.Result;
import com.example.snowball.entity.Post;
import com.example.snowball.repository.PostRepository;
import com.example.snowball.vo.PostDetailVO;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/posts")
public class PostController {

    private final PostRepository postRepository;

    public PostController(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    @GetMapping("/ping")
    public Map<String, Object> ping() {
        return Map.of(
                "time", LocalDateTime.now().toString(),
                "message", "pong"
        );
    }

    @GetMapping
    public Result<List<PostDetailVO>> getAllPosts() {
        List<Post> posts = postRepository.findAll();
        List<PostDetailVO> voList = posts.stream().map(post -> {
            PostDetailVO vo = new PostDetailVO();
            vo.setId(post.getId());
            vo.setTitle(post.getTitle());
            vo.setBody(post.getCurrentBody());
            vo.setType(post.getType().name());
            vo.setVersion(post.getVersion());
            vo.setCreatedAt(post.getCreatedAt());
            return vo;
        }).toList();
        return Result.success(voList);
    }

    @PostMapping
    public Result<PostDetailVO> createPost(@RequestBody com.example.snowball.dto.PostCreateDTO dto) {
        Long mockUserId = 1L;
        Post post = new Post();
        post.setUserId(mockUserId);
        post.setType(Post.PostType.valueOf(dto.getType()));
        post.setTitle(dto.getTitle());
        post.setCurrentBody(dto.getBody());
        postRepository.save(post);

        PostDetailVO vo = new PostDetailVO();
        vo.setId(post.getId());
        vo.setTitle(post.getTitle());
        vo.setBody(post.getCurrentBody());
        vo.setType(post.getType().name());
        vo.setVersion(post.getVersion());
        vo.setCreatedAt(post.getCreatedAt());
        return Result.success(vo);
    }
}
