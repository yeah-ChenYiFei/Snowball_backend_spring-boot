package com.example.snowball.repository;

import com.example.snowball.entity.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepository extends JpaRepository<Post, Long> {
    // 按用户查询帖子列表（文档 4.3 索引设计对应）
    Page<Post> findByUserIdOrderByCreatedAtDesc(Long userId, Pageable pageable);
}
