package com.example.snowball.service;

import com.example.snowball.dto.PostCreateDTO;
import com.example.snowball.entity.Post;
import com.example.snowball.vo.PostDetailVO;

public interface PostService {
    PostDetailVO createPost(Long userId, PostCreateDTO dto);
}
