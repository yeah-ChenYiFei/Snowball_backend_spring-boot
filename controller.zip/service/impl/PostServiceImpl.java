package com.example.snowball.service.impl;

import com.example.snowball.dto.PostCreateDTO;
import com.example.snowball.entity.Post;
import com.example.snowball.entity.PostVersion;
import com.example.snowball.repository.PostRepository;
import com.example.snowball.repository.PostVersionRepository;
import com.example.snowball.service.PostService;
import com.example.snowball.vo.PostDetailVO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;
    private final PostVersionRepository postVersionRepository;

    public PostServiceImpl(PostRepository postRepository, PostVersionRepository postVersionRepository) {
        this.postRepository = postRepository;
        this.postVersionRepository = postVersionRepository;
    }

    @Override
    @Transactional // 必须加事务，保证帖子创建和版本记录原子性
    public PostDetailVO createPost(Long userId, PostCreateDTO dto) {
        // 1. 创建帖子主体
        Post post = new Post();
        post.setUserId(userId);
        post.setType(Post.PostType.valueOf(dto.getType()));
        post.setTitle(dto.getTitle());
        post.setCurrentBody(dto.getBody());
        postRepository.save(post);

        // 2. 生成初始版本记录（借鉴 Git commit 理念）
        PostVersion version = new PostVersion();
        version.setPostId(post.getId());
        version.setVersionNumber(1);
        version.setBodySnapshot(dto.getBody());
        version.setChangeSummary("初始创建");
        postVersionRepository.save(version);

        // 3. 组装返回视图对象
        PostDetailVO vo = new PostDetailVO();
        vo.setId(post.getId());
        vo.setTitle(post.getTitle());
        vo.setBody(post.getCurrentBody());
        vo.setType(post.getType().name());
        vo.setVersion(post.getVersion());
        return vo;
    }
}
